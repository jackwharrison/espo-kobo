<?php

namespace Espo\Modules\Custom\Controllers;

class ChadDemo extends \Espo\Core\Templates\Controllers\Base
{}
