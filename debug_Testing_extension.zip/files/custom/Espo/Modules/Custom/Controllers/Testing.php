<?php

namespace Espo\Modules\Custom\Controllers;

class Testing extends \Espo\Core\Templates\Controllers\Base
{}
