<?php

namespace Espo\Modules\Custom\Controllers;

class Ctest123 extends \Espo\Core\Templates\Controllers\Base
{}
