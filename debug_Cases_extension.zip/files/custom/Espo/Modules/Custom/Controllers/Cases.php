<?php

namespace Espo\Modules\Custom\Controllers;

class Cases extends \Espo\Core\Templates\Controllers\Base
{}
