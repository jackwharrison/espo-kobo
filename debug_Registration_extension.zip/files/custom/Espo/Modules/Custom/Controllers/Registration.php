<?php

namespace Espo\Modules\Custom\Controllers;

class Registration extends \Espo\Core\Templates\Controllers\Base
{}
